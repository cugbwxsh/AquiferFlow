// AqFlowDoc.cpp : implementation of the CAqFlowDoc class
//

#include "stdafx.h"
#include "AqFlow.h"
#include "AqFlowDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAqFlowDoc
IMPLEMENT_DYNCREATE(CAqFlowDoc, CDocument)

BEGIN_MESSAGE_MAP(CAqFlowDoc, CDocument)
	//{{AFX_MSG_MAP(CAqFlowDoc)
	ON_COMMAND(ID_TOOL_TEST, OnToolTest)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAqFlowDoc construction/destruction

CAqFlowDoc::CAqFlowDoc()
{
	// TODO: add one-time construction code here
    isRun=FALSE;

    mRunInfo.mStepIndex=0;            //ʱ��
    mRunInfo.mStepMax=0;              //���ʱ����
    mRunInfo.mSP_Count=0;             //�ض����̴�������
    mRunInfo.mSP_MAX=0;               //�ض����̴���������
    mRunInfo.mEQ_ItCount=0;           //����������������
    mRunInfo.mDfMax=-1;               //������������仯����
	mRunInfo.mStMax=0;
	//��������
    mRunInfo.mStat=_T("Waiting for Running !");                 
}

CAqFlowDoc::~CAqFlowDoc()
{

}

BOOL CAqFlowDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CAqFlowDoc serialization

void CAqFlowDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CAqFlowDoc diagnostics

#ifdef _DEBUG
void CAqFlowDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CAqFlowDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CAqFlowDoc commands

void CAqFlowDoc::OnToolTest() 
{
	if(mRunInfo.mDfMax>=0)
		return;
     
	CWinThread *runModel;   //�߳�
    runModel=::AfxBeginThread(ModelRunOffLine, &mRunInfo);
}

