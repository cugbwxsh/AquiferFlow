//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AqFlow.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_AQFLOW_FORM                 101
#define IDR_MAINFRAME                   128
#define IDR_AQFLOWTYPE                  129
#define IDC_STAT                        1001
#define IDC_DFMAX                       1002
#define IDC_ITCOUNT                     1003
#define IDC_SPCOUNT                     1004
#define IDC_SPPROG                      1005
#define IDC_TIMESTEP                    1006
#define IDC_SPSTEP                      1007
#define IDC_STMAX                       1008
#define ID_TOOL_TEST                    32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
