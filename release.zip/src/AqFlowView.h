// AqFlowView.h : interface of the CAqFlowView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_AQFLOWVIEW_H__1EEE0E23_F326_4199_839B_ACD2EE1331AF__INCLUDED_)
#define AFX_AQFLOWVIEW_H__1EEE0E23_F326_4199_839B_ACD2EE1331AF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CAqFlowView : public CFormView
{
protected: // create from serialization only
	CAqFlowView();
	DECLARE_DYNCREATE(CAqFlowView)

public:
	//{{AFX_DATA(CAqFlowView)
	enum { IDD = IDD_AQFLOW_FORM };
	CProgressCtrl	m_SpStep;
	CProgressCtrl	m_SpProg;
	CString	m_Stat;
	float	m_DfMax;
	int		m_ItCount;
	int		m_SpCount;
	int		m_Step;
	float	m_StMax;
	//}}AFX_DATA

// Attributes
public:
	CAqFlowDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAqFlowView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual void OnDraw(CDC* pDC);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CAqFlowView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CAqFlowView)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in AqFlowView.cpp
inline CAqFlowDoc* CAqFlowView::GetDocument()
   { return (CAqFlowDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AQFLOWVIEW_H__1EEE0E23_F326_4199_839B_ACD2EE1331AF__INCLUDED_)
