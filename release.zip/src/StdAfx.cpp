// stdafx.cpp : source file that includes just the standard includes
//	AqFlow.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"
#include "ModHydro.h"

//ת���������ߵ�����
BOOL ConvertCurve()
{
    FCurve cOld,cNew;
    FILE   *fpOld,*fpNew;
	int    k,np_new;
	float  f_pi,dat_pi;
	BOOL   T;

    fpOld=fopen("D:\\temp\\temp-old.txt","r");
	T=cOld.ReadFile(fpOld);
    if(T)fclose(fpOld);
    fpNew=fopen("D:\\temp\\temp-new.txt","r");
	T=cNew.ReadFile(fpNew);
    if(T)fclose(fpNew);

	np_new=cNew.NumberOfNode();
    for(k=0;k<np_new;k++)
	{
	    f_pi=cNew.mp[k].x;
		dat_pi=cOld.GetY_P(f_pi);
		cNew.mp[k].y=dat_pi;
	}

    fpNew=fopen("D:\\temp\\temp.txt","w");
	fprintf(fpNew,"day,h\n");
	for(k=0;k<np_new;k++)
	    fprintf(fpNew,"%f,%f\n",cNew.mp[k].x,cNew.mp[k].y);
    if(T)fclose(fpNew);

	return T;
}
