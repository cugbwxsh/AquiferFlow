// AqFlowView.cpp : implementation of the CAqFlowView class
//

#include "stdafx.h"
#include "AqFlow.h"

#include "AqFlowDoc.h"
#include "AqFlowView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAqFlowView

IMPLEMENT_DYNCREATE(CAqFlowView, CFormView)

BEGIN_MESSAGE_MAP(CAqFlowView, CFormView)
	//{{AFX_MSG_MAP(CAqFlowView)
	ON_WM_TIMER()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAqFlowView construction/destruction

CAqFlowView::CAqFlowView()
	: CFormView(CAqFlowView::IDD)
{
	//{{AFX_DATA_INIT(CAqFlowView)
	m_Stat = _T("");
	m_DfMax = 0.0f;
	m_ItCount = 0;
	m_SpCount = 0;
	m_Step = 0;
	m_StMax = 0.0f;
	//}}AFX_DATA_INIT
	// TODO: add construction code here
}

CAqFlowView::~CAqFlowView()
{
}

void CAqFlowView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAqFlowView)
	DDX_Control(pDX, IDC_SPSTEP, m_SpStep);
	DDX_Control(pDX, IDC_SPPROG, m_SpProg);
	DDX_Text(pDX, IDC_STAT, m_Stat);
	DDX_Text(pDX, IDC_DFMAX, m_DfMax);
	DDX_Text(pDX, IDC_ITCOUNT, m_ItCount);
	DDX_Text(pDX, IDC_SPCOUNT, m_SpCount);
	DDX_Text(pDX, IDC_TIMESTEP, m_Step);
	DDX_Text(pDX, IDC_STMAX, m_StMax);
	//}}AFX_DATA_MAP
}

BOOL CAqFlowView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CAqFlowView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();
    //����һ��ʱ��
    SetTimer(1,100,NULL);

    m_SpProg.SetRange(0,100);
    m_SpProg.SetPos(0);
    
	m_SpStep.SetRange(0,100);
    m_SpStep.SetPos(0);
}

/////////////////////////////////////////////////////////////////////////////
// CAqFlowView diagnostics

#ifdef _DEBUG
void CAqFlowView::AssertValid() const
{
	CFormView::AssertValid();
}

void CAqFlowView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CAqFlowDoc* CAqFlowView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAqFlowDoc)));
	return (CAqFlowDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CAqFlowView message handlers

void CAqFlowView::OnDraw(CDC* pDC) 
{

}

void CAqFlowView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	CAqFlowDoc *pDoc;
    float       pos;

	pDoc=GetDocument();
	m_Stat=   pDoc->mRunInfo.mStat;
	m_DfMax=  pDoc->mRunInfo.mDfMax;
	m_StMax=  pDoc->mRunInfo.mStMax;
    m_ItCount=pDoc->mRunInfo.mEQ_ItCount;
	m_SpCount=pDoc->mRunInfo.mSP_Count;
	m_Step   =pDoc->mRunInfo.mStepIndex;

	pos=100*(float)pDoc->mRunInfo.mSP_Count/(float)pDoc->mRunInfo.mSP_MAX;
    m_SpProg.SetPos((int)pos);

	pos=100*(float)(pDoc->mRunInfo.mStepIndex-1)/(float)pDoc->mRunInfo.mStepMax;
    m_SpStep.SetPos((int)pos);

	UpdateData(FALSE);
	CFormView::OnTimer(nIDEvent);
}

void CAqFlowView::OnClose() 
{
    //ɾ��һ��ʱ��
	KillTimer(1);	
	CFormView::OnClose();
}
